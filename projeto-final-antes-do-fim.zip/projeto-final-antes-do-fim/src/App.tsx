import { useState } from "react";
import { Button } from "./components/Button/Button";
import { Contador } from "./components/Contador";

const nomesIniciais = ["Saitama", "Lelouch", "Madara", "Luffy"];

function App() {

  const [nomes, setNomes] = useState(nomesIniciais);

  const [novoPersonagem, setNovoPersonagem] = useState("");
  
  const nomesList = nomes.map((nome, index) => <li key={index}>{nome}</li>);

  function addPersonagem() {
    const nomesAtualizado = nomes.concat(novoPersonagem);
    setNomes(nomesAtualizado);
    setNovoPersonagem("");
  }

  return (
    <div>
      <Contador />O projeto final antes do fim II : O inimigo agora é outro
      <Button quandoClica={doritosClick}>Doritos</Button>
      <Button quandoClica={rufflesClick}>Ruffles</Button>
      <input
        type="text"
        onChange={(event) => setNovoPersonagem(event.target.value)}
        value={novoPersonagem}
      />
      <Button quandoClica={addPersonagem}>Adiciona personagem</Button>
      <ul>{nomesList}</ul>
    </div>
  );
}

function doritosClick() {
  alert("doritos");
}

function rufflesClick() {
  alert("ruffles");
}

export default App;
