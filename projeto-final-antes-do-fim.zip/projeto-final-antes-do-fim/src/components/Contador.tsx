import { useState } from "react";
import { Button } from "./Button/Button";

export function Contador() {
  const [contador, setContador] = useState(0);

  function decrementa() {
    setContador(contador - 1);
  }

  function incrementa() {
    setContador(contador + 1);
  }

  return (
    <div>
      <Button quandoClica={decrementa}>-</Button>
      <div>{contador}</div>
      <Button quandoClica={incrementa}>+</Button>
    </div>
  );
}
