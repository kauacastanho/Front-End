export default function Title({children}) {
    return <h1 className="text-xl font-bold my-2 text-center">{children}</h1>;
}