
type NomeCompletoProps = {
    firstName: string
    lastName: string
}

export function NomeCompleto(props: NomeCompletoProps) {
    return <p>{props.firstName} {props.lastName}</p>
}