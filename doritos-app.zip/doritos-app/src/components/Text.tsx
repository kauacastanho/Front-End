
export function Text({children}) {
    return <p>{children}</p>
}