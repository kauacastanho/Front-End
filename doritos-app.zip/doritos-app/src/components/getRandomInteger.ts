
export default function getRandomNumber() {
    return Math.floor(Math.random() * 100);
}