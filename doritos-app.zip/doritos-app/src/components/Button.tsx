export default function Button() {
  return <button>botao</button>;
}
