

export function HelloWorld() {

    return <h1>Olá mundo</h1>
}