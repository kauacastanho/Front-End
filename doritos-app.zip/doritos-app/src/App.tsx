import "./App.css";

import { HelloWorld } from "./components/HelloWorld";

import { NomeCompleto } from "./components/NomeCompleto";

import { Text } from "./components/Text";

import "./components/getRandomInteger";
import getRandomNumber from "./components/getRandomInteger";

const firstName = "Kaua";
const lastName = "Castanho";

const vetor = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

const dobroVetor = vetor.map((number) => number * 2);
console.log(dobroVetor);

const vetorImpares = vetor.filter((number) => number % 2 != 0);
console.log(vetorImpares);

const num = getRandomNumber();

const nomes = [
  { firstName: "Maeve", lastName: "Walaric" },

  { firstName: "Timo", lastName: "Berthild" },

  { firstName: "Pravina", lastName: "Zsófika" },

  { firstName: "Gratien", lastName: "Albertine" },

  { firstName: "Morris", lastName: "Badurad" },

  { firstName: "Cristóvão", lastName: "Raegan" },
];

const mapNomes = nomes.map((nome) => firstName + " " + lastName);
console.log(mapNomes);

export default function app() {
  return (
    <div>
      <HelloWorld />
      <HelloWorld />
      <HelloWorld />

      <Text>Sou um parágrafo!</Text>
      <Text>Sou outro parágrafo!</Text>
      <Text>Mais um parágrafo!</Text>
      <Text>Sou outro parágrafo!</Text>
      <Text>Sou um parágrafo!</Text>

      <NomeCompleto firstName={firstName} lastName={lastName} />

      {num}
    </div>
  );
}
