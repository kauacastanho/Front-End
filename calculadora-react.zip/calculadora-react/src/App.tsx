import { useState } from "react";
import "./App.css";

function App() {
  const [visor, setVisor] = useState("0");
  const lastCharIsNumber = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
  ].includes(visor[visor.length - 1]);

  function quandoApertaNumero(event: any) {
    const numero = event.target.innerHTML;

    if (visor === "0") {
      setVisor(numero);
      return;
    }

    const proximoVisor = visor + numero;
    setVisor(proximoVisor);
  }

  function quandoApertaOperacaoMatematica(event: any) {
    if (visor === "0") {
      return;
    }

    if (lastCharIsNumber) {
      const operador = event.target.innerHTML;
      const proximoVisor = visor + " " + operador + " ";
      setVisor(proximoVisor);
    }
  }

  function quandoApaga() {
    setVisor("0");
  }

  function mostraResultado() {
    if (lastCharIsNumber) {
      const proximoVisor = eval(visor.replaceAll("x", "*")).toString();
      setVisor(proximoVisor);
    }
  }

  return (
    <div className="calculadora">
      <input className="visor" type="text" value={visor} />
      <div className="botoes">
        <div className="linha">
          <button className="button" onClick={quandoApertaNumero}>
            1
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            2
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            3
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            4
          </button>
        </div>
        <div className="linha">
          <button className="button" onClick={quandoApertaNumero}>
            5
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            6
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            7
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            8
          </button>
        </div>
        <div className="linha">
          <button className="button" onClick={quandoApertaNumero}>
            9
          </button>
          <button className="button" onClick={quandoApertaNumero}>
            0
          </button>
          <button className="button" onClick={quandoApertaOperacaoMatematica}>
            +
          </button>
          <button className="button" onClick={quandoApertaOperacaoMatematica}>
            -
          </button>
        </div>
        <div className="linha">
          <button className="button" onClick={quandoApertaOperacaoMatematica}>
            x
          </button>
          <button className="button" onClick={quandoApertaOperacaoMatematica}>
            /
          </button>
          <button className="button" onClick={mostraResultado}>
            =
          </button>
          <button className="button" onClick={quandoApaga}>
            C
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
