import { useState } from "react";
import { Button } from "./components/Button.tsx";
import "./App.css";

let listaInicial = [];

function App() {
  const [lista, setLista] = useState(listaInicial);

  const [novaTarefa, setNovaTarefa] = useState("");

  const listaTarefas = lista.map((lista, index) => (
    <li className="item-lista" key={index}>
      {lista}
      <Button quandoClica={() => removeTarefa(index)}>-</Button>
    </li>
  ));

  function addTarefa() {
    const addNaLista = lista.concat(novaTarefa);
    setLista(addNaLista);
    setNovaTarefa("");
  }

  function removeTarefa(index) {
    const removeDaLista = lista.filter((lista, index_) => index_ !== index);
    setLista(removeDaLista);
  }

  return (
    <div className="container">
      <h2 className="title">Lista de Tarefas</h2>
      <input
        className="input"
        type="text"
        onChange={(event) => setNovaTarefa(event.target.value)}
        value={novaTarefa}
      />
        <Button quandoClica={addTarefa}>+</Button>

      <ul className="lista">{listaTarefas}</ul>
    </div>
  );
}

export default App;
